class DataTypes {
    public static void main(String[] args) {

        int a = 10;
        float b = 5.5f;
        double c = 99.99;
        char d = 'A';
        boolean e = true;

        System.out.println("int = " + a);
        System.out.println("float = " + b);
        System.out.println("double = " + c);
        System.out.println("char = " + d);
        System.out.println("boolean = " + e);
    }
}